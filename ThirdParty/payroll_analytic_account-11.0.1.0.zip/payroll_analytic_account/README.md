Odoo - Payroll Anaylitic Account
========================================

When enable in an specific Salary Rule it uses the Analytic Account selected in the Employees Contract
You can check functionality in the following video:

https://www.youtube.com/watch?v=raLA72Sfcds

## Credits
<p>
<img width="200" alt="Logo Konos" src="http://www.konos.cl/web/image/666" />
</p>
**Konos** - http://konos.cl
 - Nelson Ramírez <info@konos.cl>


 
 **Contributors**
 - Daniel Blanco Martín <daniel@blancomartin.com>